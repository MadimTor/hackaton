import os
from fabric import *

def start_sec(ip, machine):
    strr = "vncviewer " + ip + ":" + machine
    os.system(strr)

