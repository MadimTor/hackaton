import sys
import autorization
from PySide2 import QtWidgets
from main_ui import Ui_mainRedConnect
from reg_ui import Ui_Dialog
from login_ui import Ui_login_Dialog
from Connect import start_sec

global userName
userName = str()
global userPassword
userPassword = str()
global userId
userId = int(0)
global keyJoin
keyJoin = str()
global lastKeyJoin
lastKeyJoin = str()

class MainClass(QtWidgets.QMainWindow, Ui_mainRedConnect):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.show()
        self.registration_button_account.clicked.connect(self.open_Dialog)
        self.logiIn_button_account.clicked.connect(self.open_Login)
        self.dialog = Registration()
        self.dialog_login = Login()
        self.pushButton.clicked.connect(self.start_session)

    def start_session(self):
        start_sec(self.login_extrernal_connection_LineEdit.text(), self.password_extrernal_connection_LineEdit.text())


    def open_Dialog(self):
        self.dialog.show()

    def open_Login(self):
        self.dialog_login.show()

class Registration(QtWidgets.QMainWindow, Ui_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.registraion_buttom.clicked.connect(self.Autorize)

    def Autorize(self):
        global userName
        userName = self.login_registration_LineEdit.text()
        global userPasswordr
        userPassword = self.password_registration_LineEdit.text()
        result = autorization.send_register(userName, userPassword, 44)
        if result[:4] == 'id: ':
                getting = result.split(' | ')
                for elem in getting:
                        item = elem.split(': ')
                        if item[0] == 'id':
                                userId = int(item[1])
                        elif item[0] == 'keyJoin':
                                keyJoin = item[1]
                        elif item[0] == 'LastKeyJoin':
                                lastKeyJoin = item[1]
                print('%d %s %s' % (userId, keyJoin, lastKeyJoin))

        elif result == 'ConnectError':
                self.registration_label.setText("host failed")
        elif result == 'UserError':
                self.registration_label.setText("user failed")
        elif result == 'AutorizationError':
                self.registration_label.setText("failed autorization")
        elif result == 'RegisterError':
                self.registration_label.setText("failed register")
        elif result == 'RegisterSucces':
                self.registration_label.setText("Регистрация успешна!")
        else:
                self.registration_label.setText("Other Error!")


class Login(QtWidgets.QMainWindow, Ui_login_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.login_buttom.clicked.connect(self.Login)

    def Login(self):
        global userName
        userName = self.login_login_LineEdit.text()
        global userPasswordr
        userPassword = self.password_login_LineEdit.text()
        result = autorization.send_login(userName, userPassword)
        if result[:4] == 'id: ':
                getting = result.split(' | ')
                for elem in getting:
                        item = elem.split(': ')
                        if item[0] == 'id':
                                userId = int(item[1])
                        elif item[0] == 'keyJoin':
                                keyJoin = item[1]
                        elif item[0] == 'LastKeyJoin':
                                lastKeyJoin = item[1]
                print('%d %s %s' % (userId, keyJoin, lastKeyJoin))
                self.login_label.setText("Вы авторизованы!")

        elif result == 'ConnectError':
                self.login_label.setText("host failed")
        elif result == 'UserError':
                self.login_label.setText("user failed")
        elif result == 'AutorizationError':
                self.login_label.setText("failed autorization")
        elif result == 'RegisterError':
                self.login_label.setText("failed register")
        elif result == 'RegisterSucces':
                self.login_label.setText("Регистрация успешна!")
        else:
                self.login_label.setText("Other Error!")




if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    wnd = MainClass()
    sys.exit(app.exec_())
